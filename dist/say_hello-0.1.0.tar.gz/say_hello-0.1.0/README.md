# hexlet-my-first-workflow
[![CI](https://github.com/LAMENTIN28/hexlet-my-first-workflow/actions/workflows/blank.yml/badge.svg)](https://github.com/LAMENTIN28/hexlet-my-first-workflow/actions/workflows/blank.yml)
